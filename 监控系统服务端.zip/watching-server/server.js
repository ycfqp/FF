﻿var express = require('express');
var app = express();
var schedule = require("node-schedule");  
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var db = require('./dbManager.js');
var ping = require('ping');
//var oracledb = require('./oracle.js');
var oracledb = require('oracledb');
var pingTime;
app.use(express.static('public'))

app.get('/',function(req,res){
	
	res.sendFile(__dirname+'/index.html');
	
	
});
 

var errorIP;
var errormem;
var errorcpu;
var errornet;
var errorCdis;
var errorDdis;
var errorEdis;
var errorFdis;
var errorGdis;
var errordate;

var Msgto;






//ping 所有主机的函数
function pingAll(){
	//console.log('开始执行ping所有主机');
	db.query('SELECT * FROM com',function(error,rows,fileds){
		if(error) throw error;
		else{
			rows.forEach(function(data){
				
				ping.sys.probe(data.ip,function(isAlive){
					var msg = isAlive ? "on":"off";
					 var sql = 'update com set net = "' + msg + '" where ip = "' + data.ip +'"';
					 db.query(sql,function(error,rows,fileds){
						
						 if(error) throw error;
						 
						 
						 
					 })
					 
					 
					 
				})
			})
		}
		
		
		
	})
}





//从数据库中获取ping时间的函数
 function getPingTime(){
	  
	 db.query('SELECT * FROM pingtime WHERE id = 1',function(error,rows,fileds){
		 if(error) throw error;
		   pingTime = rows[0].ping;
		  //console.log(pingTime);
	 })
 }
 //为pingTime赋值
 getPingTime();
//定时ping所有主机
setTimeout(function p(){
	setInterval(function(){
		pingAll();
		console.log('ping一次');
	},pingTime);
},2000)
 
 
 

 
 
 //短信发送函数
function sendMessageError(){
	var config ={
		user : "fzYeb",
        password      : "Yebin777",
        connectString : "134.132.9.7:1521/DW"
	};
	oracledb.getConnection(
		config,
		function(err,connection){
			if(err) {
				console.log(err.message);
				return;
			}
			console.log('连接oracle成功');
				console.log(Msgto);
			connection.execute("begin dw.proc_send_sms_dw('18960955808','"+Msgto+"。当前主机状态为:内存使用率:"+errormem+"%,CPU利用率:"+errorcpu+"%,网络状态为:"+errornet+",各磁盘使用率:C:"+errorCdis+"%,D:"+errorDdis+"%,E:"+errorEdis+"%,F:"+errorFdis+"%,G:"+errorGdis+"%,异常时间为:"+new Date().toLocaleString()+"');end;",
			function(err,result){
				if(err) throw err;
				 
				 
				 
				console.log('发送完成,开始释放连接');
			})
			
			 
		}
	)
} 

function doRelease(connection){
	connection.close(
		 function(err){
			 if(err){
				 console.log(err.message);
			 }
		 }
	)
}

	




//查找内存和阈值并查询问题主机，找到问题主机插入问题表
setInterval(function findError(){
	db.query('SELECT * FROM memfz WHERE id = 1',function(error,rows,fileds){
		//console.log('得到内存阈值');
		var memMAX = rows[0].memMAX;
		//console.log(memMAX);
		
		db.query('SELECT * FROM cpufz WHERE id = 1',function(error,rows,fileds){
			//console.log('得到cpu阈值');
			var cpuMAX = rows[0].cpuMAX;
			//console.log(cpuMAX);
			db.query('SELECT * FROM disfz WHERE id=1',function(error,rows,fileds){
			//	console.log('dis阈值');
				var disMAX = rows[0].disMAX;
				//console.log(disMAX);
				
			//开始比对，找出问题主机并存储
			db.query('SELECT * FROM com',function(error,rows,fileds){
				for(let i = 0;i < rows.length;i++){
					//console.log(rows[i].ip);
					if(rows[i].mem>memMAX||rows[i].cpu>cpuMAX||rows[i].net==="off"||rows[i].Cdis>disMAX||rows[i].Ddis>disMAX||rows[i].Edis>disMAX||rows[i].Fdis>disMAX||rows[i].Gdis>disMAX){
						//console.log('出现异常');
						 
						//出现异常向表中插入异常主机
					 errorIP = rows[i].ip;
					errormem = rows[i].mem;
					errorcpu =rows[i].cpu;
					errornet = rows[i].net;
					errorCdis = rows[i].Cdis;
					 errorDdis = rows[i].Ddis;
					  errorEdis = rows[i].Edis;
					    errorFdis = rows[i].Fdis;
						 errorGdis = rows[i].Gdis;	
							 
						
						 
						 
						 
						db.query('SELECT * FROM errorcom WHERE ip ="'+rows[i].ip+'"',function(error,row,fileds){ 
						//console.log('查看异常表');
						//console.log('SELECT * FROM errorcom WHERE ip ="'+rows[i].ip+'"');
						if(row==0){
							console.log('异常未插入过');
								//短信告警
						console.log('开始发送告警短信');
						 
							
							//未插入，mysql插入主机，并短信告警
							//console.log('出现新异常,插入该异常');
				var isql ='INSERT INTO errorcom (ip,cpu,mem,net,Cdis,Ddis,Edis,Fdis,Gdis,date) values ("'+rows[i].ip+'","'+rows[i].cpu+'","'+rows[i].mem+'","'+rows[i].net+'","'+rows[i].Cdis+'","'+rows[i].Ddis+'","'+rows[i].Edis+'","'+rows[i].Fdis+'","'+rows[i].Gdis+'","'+new Date().toLocaleString()+'")'
						db.query(isql,function(error,rows,fileds){
							if(error) throw error;
							
							
							
							
							
						})
						Msgto = '主机ip为"'+rows[i].ip+'"的主机出现异常，';
						
						if(rows[i].net=="off"){
							Msgto +='"网络异常"';
						}
						if(rows[i].mem>memMAX){
							Msgto +='"内存异常"';
						}
						if(rows[i].cpu>cpuMAX){
							Msgto +='"CPU异常"';
						}
						if(rows[i].Cdis>disMAX){
							Msgto +='"C盘异常"';
						}
						if(rows[i].Ddis>disMAX){
							Msgto +='"D盘异常"';
						}
						if(rows[i].Edis>disMAX){
							Msgto +='"E盘异常"';
						}
						if(rows[i].Fdis>disMAX){
							Msgto +='"F盘异常"';
						}
						if(rows[i].Gdis>disMAX){
							Msgto +='"G盘异常"';
						}
						
						//console.log(Msgto);
						
						sendMessageError();
					 
							
							
						}else{
							//console.log('异常已经插入过');
							//已经插入，mysql不做操作
							db.query('UPDATE errorcom SET date ="'+new Date().toLocaleString()+'" WHERE ip = "'+rows[i].ip+'"',function(erorr,rows,fileds){
								if(error) throw error;
							//	console.log('更新异常');
							})
							 
						}
						})
					}else{
						
					}
				}
			})    
			})
			
		})
	})
},1000);







//定时查找异常主机






//查找内存阈值的函数
function getMemMax(){
	db.query('SELECT * FROM memfz WHERE id =1',function(error,rows,fileds){
		var memMAX = rows[0].memMAX;
		//console.log(memMAX);
	})
}
 
//查找cpu阈值的函数
function getcpuMAX(){
	db.query('SELECT * FROM cpufz WHERE id =1',function(error,rows,fileds){
		if(error) throw error;
		var cpuMAX = rows[0].cpuMAX;
		//console.log('CPU')
		//console.log(cpuMAX);
	})
}
function getdisMAX(){
	db.query('SELECT * FROM disfz WHERE id = 1',function(error,rows,fileds){
		if(error) throw error;
		var disMAX = rows[0].disMAX;
		//console.log(disMAX);
	})
}
 









server.listen(3000,function(){
	console.log('3000');
});

io.sockets.on('connection',function(socket){
    // 处理操作
	console.log('have client connect');
	socket.on('deleteMysql',function(data){
		//console.log('接收到前端要删除的IP')；
		var sql = 'DELETE FROM com WHERE ip ="'+data+'" '
		db.query(sql,function(error,rows,fileds){
			if(error) throw error;
		})
	})
	
	//接收前台想要查看目前所有阈值请求
	socket.on('wantErrorMAX',function(data){
		var fzdata = new Array();
		db.query('SELECT * FROM memfz WHERE id =1',function(error,rows,fileds){
		 fzdata[0] = rows[0].memMAX;
		 db.query('SELECT * FROM cpufz WHERE id =1',function(error,rows,fileds){
		if(error) throw error;
		fzdata[1] = rows[0].cpuMAX;
		db.query('SELECT * FROM disfz WHERE id = 1',function(error,rows,fileds){
		if(error) throw error;
		fzdata[2] = rows[0].disMAX;
		  db.query('SELECT * FROM pingtime WHERE id = 1',function(error,rows,fileds){
		 if(error) throw error;
		   fzdata[3] = rows[0].ping;
		   socket.emit('allfz',fzdata);
		   
	 })
	})
		 
	})
		 
	})
	 
		 
	})
	
	
	
	
	
	
	
	
	
	
 //接收前台想要查看异常主机请求
 socket.on('wantError',function(data){
	 var sql ='SELECT * FROM com';
	 db.query(sql,function(error,rows,fileds){
		 socket.emit('List',rows);
	 })
 })
	//接收前端清空异常表的操作
	socket.on('clearError',function(data){
		db.query('truncate table errorcom',function(error,rows,fileds){
			if(error) throw error;
		})
	})
	
	//接受前端ping时间间隔
socket.on('pingMsg',function(data){
	console.log('接受到数据');
	var sql = 'UPDATE pingTime SET ping ='+data+' WHERE id=1';
	db.query(sql,function(error,rows,fileds){
		if(error) throw error;
		socket.emit('success','更新成功!!');
	})
})
//接收前端删除主机函数
socket.on('deleteMysql',function(data){
	console.log('接收到数据');
	var sql = 'DELETE FROM com WHERE ip="'+data+'"';
	db.query(sql,function(error,rows,fileds){
		if(error) throw error;
	})
});

	
	
	
	
	
	
	//接收前台设置的内存阈值
			socket.on('sendmem',function(data){
				console.log('接收到数据');
				console.log(data);
				var sql = 'UPDATE memfz SET memMAX ="'+data+'" WHERE id=1 ';
				db.query(sql,function(error,rows,fileds){
					if(error) throw error;
				});
				
				
			});
			
			
			
			
			
			
			//接收添加主机ip
			socket.on('sendIP',function(data){
				console.log('接收到数据');
				console.log(data);
				var search = 'SELECT * FROM com WHERE ip="'+data+'"';
				var insql = 'INSERT INTO com (ip,cpu,mem,net) values ("'+data+'","null","null","null")';
				db.query(search,function(error,rows,fileds){
					if(error) console.log(error);
					if(rows!=0){
						console.log('此主机ip已经添加过');
						socket.emit('added','主机已经添加过，请勿重复添加');
					}else{
						db.query(insql,function(error,rows,fileds){
							if(error) throw error;
							socket.emit('addsuccess','添加成功!');
						})
					}
					
				})
			})
			
			
			//接收CPU阈值
			socket.on('sendcpu',function(data){
				console.log('接收到数据');
				console.log(data);
				var sql = 'UPDATE cpufz SET cpuMAX ="'+data+'" WHERE id=1 ';
				db.query(sql,function(error,rows,fileds){
					if(error) throw error;
				})
			})
		
		
	//接收前端传来磁盘阈值
	socket.on('disMsg',function(data){
		console.log('接收到磁盘数据');
		console.log(data);
		db.query('UPDATE disfz SET disMAX ="'+data+'" WHERE id = 1',function(error,rows,fileds){
			if(error) throw error;
			console.log('执行完更新语句');
		})
		
	})
			//接受客户端传来的主机硬件信息
		socket.on('com',function(com){
			
			if(com.adress=="undefined"){
				console.log(com.adress);
				console.log('不接受');
				return null;
			}else{
				db.query('SELECT * FROM com WHERE ip ="'+com.adress+'"',function(error,rows,fileds){
					if(error) throw error;
					if(rows==0){
						console.log('未插入此主机');
						db.query('INSERT INTO com (ip,cpu,mem,net,Cdis,Ddis,Edis,Fdis,Gdis) values ("'+com.adress+'","'+com.cpu+'","'+com.mem+'","'+com.net+'","'+com.Cdis+'","'+com.Ddis+'","'+com.Edis+'","'+com.Fdis+'","'+com.Gdis+'")',function(error,rows,fileds){
							if(error) throw error;
							console.log('插入成功');
						})
					}else{
						var sql = 'UPDATE com SET cpu="'+com.cpu+'",mem="'+com.mem+'",Cdis="'+com.Cdis+'",Ddis="'+com.Ddis+'",Edis="'+com.Edis+'",Fdis="'+com.Fdis+'",Gdis="'+com.Gdis+'" WHERE ip = "'+com.adress+'"';
						db.query(sql,function(error,rows,fileds){
							if(error) throw error;
							//console.log('更新成功');
							
						})
					}
				})
			}
			 
		})
		
		
		
	
		
		
		  
	
//前端展示函数
		function showAll(){
	db.query('SELECT * FROM errorcom',function(error,rows,fileds){
		if(error) throw error;
	//	console.log(rows);
		socket.emit('mysql',rows);
	})
}

//定时执行展示函数
setInterval(function(){showAll()},2000);
	
	});
		
		

	
	
	
	


	

