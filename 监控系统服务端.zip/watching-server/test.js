var x = 1;
switch(true){
	case(x>0):{console.log('1');}
	case(x==1):{console.log('4');
	console.log('qqq');
	}
	
	
}
console.log('退出switch')
