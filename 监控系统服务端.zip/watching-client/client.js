var io = require('socket.io-client');
var net = require('net');
var os = require('os');
var exec = require('child_process').exec;
var cpuStat = require('cpu-stat');
const ip = "192.168.3.23";
const port = 3000;

var CDisUsage;
var EDisUsage;
var FDisUsage;
var DDisUsage;
var GDisUsage;


var cpuUsage;
function host(){
	//获取各个盘的使用率
	exec('fsutil volume diskfree c:',function(err,stdout,stderr){
		if(err){
			CDisUsage=0;
			
		}else{
	
	 
		 
		 var tmp =  stdout.split(":");
		// console.log(tmp);
		var tmp2 = new Array();
		 for(let i = 0;i<tmp.length;i++)
			  
		       tmp2[i] = tmp[i].replace(/[^\d\s]/g,'');
		// console.log(tmp2);
		 var tmp3 = new Array()
		 for(let j=0;j<tmp2.length;j++)
			 tmp3[j]=tmp2[j].replace(/[^\d.]/g,"")
		 for(let t = 0;t<tmp3.length;t++)
		// console.log(tmp3[t]);
	//	console.log('磁盘空闲为:'+tmp3[1]);
	//	console.log('磁盘总空间为'+tmp3[2]);
		CDisUsage = ((1 -(tmp3[1]/tmp3[2]))*100).toFixed(2);
	//	console.log(CDisUsage);
			}    
	});
		exec('fsutil volume diskfree e:',function(err,stdout,stderr){
if(err){
			EDisUsage=0;
			
		}else{
	
	 
		 
		 var tmp =  stdout.split(":");
		// console.log(tmp);
		var tmp2 = new Array();
		 for(let i = 0;i<tmp.length;i++)
			  
		       tmp2[i] = tmp[i].replace(/[^\d\s]/g,'');
		// console.log(tmp2);
		 var tmp3 = new Array()
		 for(let j=0;j<tmp2.length;j++)
			 tmp3[j]=tmp2[j].replace(/[^\d.]/g,"")
		 for(let t = 0;t<tmp3.length;t++)
	//	 console.log(tmp3[t]);
	//	console.log('磁盘空闲为:'+tmp3[1]);
	//	console.log('磁盘总空间为'+tmp3[2]);
		EDisUsage = ((1 -(tmp3[1]/tmp3[2]))*100).toFixed(2);
	//	console.log(EDisUsage);
		}
	});
	exec('fsutil volume diskfree F:',function(err,stdout,stderr){
if(err){
			FDisUsage=0;
			
		}else{
	 
		 
		 var tmp =  stdout.split(":");
		// console.log(tmp);
		var tmp2 = new Array();
		 for(let i = 0;i<tmp.length;i++)
			  
		       tmp2[i] = tmp[i].replace(/[^\d\s]/g,'');
		// console.log(tmp2);
		 var tmp3 = new Array()
		 for(let j=0;j<tmp2.length;j++)
			 tmp3[j]=tmp2[j].replace(/[^\d.]/g,"")
		 for(let t = 0;t<tmp3.length;t++)
		 //console.log(tmp3[t]);
		//console.log('磁盘空闲为:'+tmp3[1]);
		//console.log('磁盘总空间为'+tmp3[2]);
		FDisUsage = ((1 -(tmp3[1]/tmp3[2]))*100).toFixed(2);
		//console.log(FDisUsage);
		}
	});
	exec('fsutil volume diskfree G:',function(err,stdout,stderr){
		if(err){
			GDisUsage=0;
			
		}else{
		 
		 var tmp =  stdout.split(":");
		// console.log(tmp);
		var tmp2 = new Array();
		 for(let i = 0;i<tmp.length;i++)
			  
		       tmp2[i] = tmp[i].replace(/[^\d\s]/g,'');
		// console.log(tmp2);
		 var tmp3 = new Array()
		 for(let j=0;j<tmp2.length;j++)
			 tmp3[j]=tmp2[j].replace(/[^\d.]/g,"")
		 for(let t = 0;t<tmp3.length;t++)
		 //console.log(tmp3[t]);
		//console.log('磁盘空闲为:'+tmp3[1]);
		//console.log('磁盘总空间为'+tmp3[2]);
		GDisUsage = ((1 -(tmp3[1]/tmp3[2]))*100).toFixed(2);
		//console.log(EDisUsage);
		}
	});
	exec('fsutil volume diskfree D:',function(err,stdout,stderr){
		if(err){
			DDisUsage=0;
			
		}else{
		 
		 var tmp =  stdout.split(":");
		// console.log(tmp);
		var tmp2 = new Array();
		 for(let i = 0;i<tmp.length;i++)
			  
		       tmp2[i] = tmp[i].replace(/[^\d\s]/g,'');
		// console.log(tmp2);
		 var tmp3 = new Array()
		 for(let j=0;j<tmp2.length;j++)
			 tmp3[j]=tmp2[j].replace(/[^\d.]/g,"")
		 for(let t = 0;t<tmp3.length;t++)
	//	 console.log(tmp3[t]);
	//	console.log('磁盘空闲为:'+tmp3[1]);
		//console.log('磁盘总空间为'+tmp3[2]);
		DDisUsage = ((1 -(tmp3[1]/tmp3[2]))*100).toFixed(2);
		//console.log(DDisUsage);
		}
	});
	
	
	
	
	
	
function getCDis(){
	return CDisUsage;
}
function getFDis(){
	return FDisUsage;
}
function getDDis(){
	return DDisUsage;
}
function getEDis(){
	return EDisUsage;
}
function getGDis(){
	return GDisUsage;
}
	
	
	
	
	
	
	
	
	
	
//获得主机内存信息
function getMem(){
var memUsage = ((1-(os.freemem()/os.totalmem()))*100).toFixed(2);
return memUsage;
}



//获得CPU使用率
cpuStat.usagePercent(function(err, percent, seconds) {

    if (err) {

 return console.log(err);

}
	cpuUsage =percent.toFixed(2);
	 return percent;
	}	
	

  ) ;
 function getCPU(){
	 return cpuUsage;
 }


//获得主机ip地址
function getIPAdress(){  
    var interfaces = require('os').networkInterfaces();  
    for(var devName in interfaces){  
          var iface = interfaces[devName];  
          for(var i=0;i<iface.length;i++){  
               var alias = iface[i];  
               if(alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal){  
                     return alias.address;  
               }  
          }  
    }  
} 

var ipp = getIPAdress();





//设置主机对象
var com = {
	'adress':getIPAdress(),
	'cpu':getCPU(),
	'mem' : getMem(),
	'Cdis' : getCDis(),
	'Fdis' : getFDis(),
	'Gdis' : getGDis(),
	'Edis' : getEDis(),
	'Ddis' : getDDis()
}
return com;


}



var socket = io.connect('http://'+ip+':'+port+'', {reconnect: true});//{reconnect: true}断开再重连，不建议使用，自行控制

socket.on('connect', function (socket) {//绑定连接上服务器之后触发的数据
    console.log('have connected the server!');
});

setInterval(function(){socket.emit('com', host());
console.log(host())

},1000);//





